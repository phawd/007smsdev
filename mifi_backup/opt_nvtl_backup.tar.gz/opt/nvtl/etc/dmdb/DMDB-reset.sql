DELETE FROM GlobalDataCounters;

DELETE FROM SiteAccess;

DELETE FROM KnownDevices;

DELETE FROM DataSessions;

DELETE FROM UsageLogs;

DELETE FROM SimInfo;

DELETE FROM DataPlanResetDate;









