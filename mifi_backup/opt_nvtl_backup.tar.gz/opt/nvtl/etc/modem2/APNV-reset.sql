DELETE FROM ValidAPNs;









