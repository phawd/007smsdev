#!/bin/sh
#
# sync.sh <delay_seconds>
#

if [ $# -lt 1 ]; then
	echo "usage: sync.sh <delay_seconds>"
	exit 1
fi

delay_seconds=$1

while true; do
	sleep $delay_seconds
	sync
	sync
done

exit 0
