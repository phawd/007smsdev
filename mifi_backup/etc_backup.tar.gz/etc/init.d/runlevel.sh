#!/bin/sh
# INIT script for detecting runlevel transitions
# The stop command will remove the file /var/run/runlevel.
# The start command will create the file /var/run/runlevel,
#   writing the output of the runlevel command into it.

case "$1" in
  start)
	/sbin/runlevel > /var/run/runlevel
	FROMTO=`cat /var/run/runlevel`
	logger -p local1.crit -t init "[INIT]:[notice] - {mifios_sysevent}:Finished run level transition $FROMTO"
        ;;
  stop)
	/bin/rm -f /var/run/runlevel
        ;;
  *)
        echo "Usage $0 { start | stop }" >&2
        exit 1
        ;;
esac

exit 0

