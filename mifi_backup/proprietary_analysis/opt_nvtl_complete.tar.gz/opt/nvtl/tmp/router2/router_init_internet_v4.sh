#!/bin/sh

ROUTER_CMD_LOGS=/opt/nvtl/tmp/router2/router2-log 

print_if_failed () 
{ 
    if [ `wc -l $ROUTER_CMD_LOGS | cut -d ' ' -f1` -gt 3000 ]; then 
        echo "$(tail -n 500 $ROUTER_CMD_LOGS)" > $ROUTER_CMD_LOGS 
        printf '.....TRUNCATED....\n' >> $ROUTER_CMD_LOGS 
    fi 
    printf "`date |tr -s ' '|cut -d ' ' -f1,3,4` CMD: "%s" from "%s". \n" "$*"  "$0" >>$ROUTER_CMD_LOGS 
    $@ 2>> $ROUTER_CMD_LOGS && return  
    st=$? 
    cmd="$*" 
    printf 'Command: "%s" FAILED with status %d from "%s" Please Fix \n' "$*" "$st" "$0" >>$ROUTER_CMD_LOGS 
    nvtl_log -p 1 -m "ROUTER" -l "error" -s "Command: $cmd, FAILED with status $st from "$0"." 
    return $st 
}

print_command () 
{ 
    printf 'Executing cmd: "%s" from "%s". \n' "$*"  "$0" >> $ROUTER_CMD_LOGS 
}


# Test script hooks for debugging only.
if [ -f /root/router_test_init_v4_s.sh ]
then
    print_if_failed source /root/router_test_init_v4_s.sh
fi
# bring up interface and route.
print_if_failed ifconfig rmnet_data0 down 
print_if_failed ifconfig rmnet_data0 10.239.133.117 netmask 255.255.255.255 up
print_if_failed route add default dev rmnet_data0 
# Set the default policy on IPV4 INPUT, OUTPUT, FORWARD tables to DROP
# Only traffic expressly permitted will be allowed
print_if_failed iptables -P INPUT DROP
print_if_failed iptables -P FORWARD DROP
print_if_failed iptables -P OUTPUT DROP

# Allow all traffic to and from the local bridge interface
print_if_failed iptables -A INPUT -i br0 -j ACCEPT
print_if_failed iptables -A OUTPUT -o br0 -j ACCEPT

print_if_failed iptables -A INPUT -p icmp -i rmnet_data0 --icmp-type fragmentation-needed -j ACCEPT
# Allow outbound and inbound for FOTA/OTADM
print_if_failed iptables -A OUTPUT  -j ACCEPT
print_if_failed iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

# Allow all traffic from the router itself
print_if_failed iptables -A INPUT -i lo -j ACCEPT
print_if_failed iptables -A OUTPUT -o lo -j ACCEPT

# Allow client traffic back and forth
print_if_failed iptables -A FORWARD -i br0 -o br0 -j ACCEPT 

# Sets up basic NAT routing
print_if_failed iptables -t nat -A POSTROUTING -o rmnet_data0 -j MASQUERADE

# Adds rules to allow local outbound traffic from the router to the public internet.
# Validates that privately sourced IP packets are not allowed to leave.
print_if_failed iptables -A OUTPUT -o rmnet_data0 ! -s 192.168.11.0/24 -j ACCEPT

# prevent inbound tcp requests.
print_if_failed iptables -I INPUT -p tcp -i rmnet_data0 -d 10.239.133.117 -m state --state NEW -j REJECT --reject-with tcp-reset
# prevent inbound udp requests.
print_if_failed iptables -I INPUT -p udp -i rmnet_data0 -d 10.239.133.117 -m state --state NEW -j REJECT --reject-with icmp-port-unreachable
# Allow all established traffic patterns from public internet.
print_if_failed iptables -I INPUT -i rmnet_data0 -m state --state ESTABLISHED,RELATED -j ACCEPT
# setup any other rules to allow public internet.
print_if_failed sh /opt/nvtl/tmp/router2/init_public_access.sh

# Enforces MTU/MSS by enforcing tcp/MSS clamping on both inbound and outpund TCP connections
print_if_failed ifconfig rmnet_data0 mtu 1430
print_if_failed iptables -t mangle -A PREROUTING -p tcp --tcp-flags SYN,RST SYN -i rmnet_data0 -j TCPMSS --set-mss 1390
print_if_failed iptables -t mangle -A POSTROUTING -p tcp --tcp-flags SYN,RST SYN -o rmnet_data0 -j TCPMSS --set-mss 1390

# Setups VPN passthrough rules
print_if_failed sh /opt/nvtl/tmp/router2/init_vpn_conn.sh

# Sets up outbound port filtering rules on FORWARD table from LAN to WAN
#
# Allow all normal outbound traffic from LAN to WAN
# Enforce state here to prevent packets for invalid or unknown connections to
# escape without being NAT'd
print_if_failed iptables -A FORWARD -i br0 -o rmnet_data0 -m state --state NEW,ESTABLISHED,RELATED -j ACCEPT
# Do not forward Acknoledgement for FIN (socket finshed), and RST (socket err).
# They seem to sometimes fail NAT and leak to the public internet.  Possibly the NAT is clearing state?
print_if_failed sh /opt/nvtl/tmp/router2/init_port_filter.sh

# allow forwarding basic inbound traffic from WAN to LAN
print_if_failed iptables -A FORWARD -i rmnet_data0 -o br0 -m state --state ESTABLISHED,RELATED -j ACCEPT
print_if_failed sh /opt/nvtl/tmp/router2/init_port_forward.sh

# Setup DMZ rules
print_if_failed sh /opt/nvtl/tmp/router2/init_dmz.sh


# Enable all forwarding
echo "1" > /proc/sys/net/ipv4/ip_forward 
print_command echo "1" \> /proc/sys/net/ipv4/ip_forward 


# Test script hooks for debugging only.
if [ -f /root/router_test_init_v4_e.sh ]
then
    print_if_failed source /root/router_test_init_v4_e.sh
fi
print_if_failed exit 0
