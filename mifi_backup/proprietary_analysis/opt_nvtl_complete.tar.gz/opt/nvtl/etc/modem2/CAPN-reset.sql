DELETE FROM CustomAPN;









